"""Pydantic models for scoring results and ranking (plan.md §15)."""

from __future__ import annotations

from pydantic import BaseModel, Field


class CandidateResult(BaseModel):
    """Complete scoring result for a single candidate."""

    candidate_name: str
    keyword_score: float = Field(
        default=0.0, ge=0.0, le=100.0, description="Keyword matching score (0-100)"
    )
    semantic_score: float = Field(
        default=0.0, ge=0.0, le=100.0, description="Semantic similarity score (0-100)"
    )
    final_score: float = Field(
        default=0.0, ge=0.0, le=100.0, description="Weighted final score (0-100)"
    )

    # Evidence for explainability
    matched_required_skills: list[str] = Field(default_factory=list)
    missing_required_skills: list[str] = Field(default_factory=list)
    matched_preferred_skills: list[str] = Field(default_factory=list)
    missing_preferred_skills: list[str] = Field(default_factory=list)

    # Top-3 explanation (generated deterministically from evidence)
    explanation: str | None = Field(
        default=None, description="Natural-language explanation (top 3 only)"
    )


class RankingResult(BaseModel):
    """Full ranking output for all candidates."""

    jd_role_title: str | None = None
    candidates: list[CandidateResult] = Field(
        default_factory=list,
        description="All candidates sorted by final_score descending",
    )

    @property
    def top_3(self) -> list[CandidateResult]:
        """Return the top 3 candidates."""
        return self.candidates[:3]
